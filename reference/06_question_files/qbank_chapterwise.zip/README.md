# qbank_chapterwise

Built from `~/buildpack/papers.json` (read-only source; not modified).


## Structure

```
qbank/
  <Subject>/<Chapter>.json   - questions for that chapter, full fields + paper_id/paper_title
  index.json                 - every chapter: subject, file, question_count, difficulty_counts
  papers_map.json            - per paper: title/duration/marks/sections/marking_scheme + ordered [chapter_file, question_number]
images/                       - WebP images referenced by questions, max width 900px
```

## Counts

- Total questions: 3175
- Total papers: 105
- Total chapters: 74
  - Chemistry: 1075 questions
  - Maths: 925 questions
  - Physics: 1175 questions
- Images copied: 1823

## Data quality notes

- Questions missing subject/chapter: 0 (none)
- Questions with no correct answer recorded: 1
  - master_bank_id=MB002439 paper_id=6929505e613450764b62cd75 question_number=14
- Questions with no solution (no text, no image): 56
  - master_bank_id=MB002982 paper_id=692ec74553dfe02e722eb64b question_number=32
  - master_bank_id=MB003044 paper_id=692ec8150db307379499d9e1 question_number=19
  - master_bank_id=MB002501 paper_id=692ebdcf53dfe02e722e3243 question_number=1
  - master_bank_id=MB002503 paper_id=692ebdcf53dfe02e722e3243 question_number=3
  - master_bank_id=MB002506 paper_id=692ebdcf53dfe02e722e3243 question_number=6
  - master_bank_id=MB002508 paper_id=692ebdcf53dfe02e722e3243 question_number=8
  - master_bank_id=MB002509 paper_id=692ebdcf53dfe02e722e3243 question_number=9
  - master_bank_id=MB002510 paper_id=692ebdcf53dfe02e722e3243 question_number=10
  - master_bank_id=MB002512 paper_id=692ebdcf53dfe02e722e3243 question_number=12
  - master_bank_id=MB002513 paper_id=692ebdcf53dfe02e722e3243 question_number=13
  - master_bank_id=MB002525 paper_id=692ebdcf53dfe02e722e3243 question_number=25
  - master_bank_id=MB002577 paper_id=692ebeca613450764b9d8b9e question_number=2
  - master_bank_id=MB002578 paper_id=692ebeca613450764b9d8b9e question_number=3
  - master_bank_id=MB002579 paper_id=692ebeca613450764b9d8b9e question_number=4
  - master_bank_id=MB002582 paper_id=692ebeca613450764b9d8b9e question_number=7
  - master_bank_id=MB002584 paper_id=692ebeca613450764b9d8b9e question_number=9
  - master_bank_id=MB002589 paper_id=692ebeca613450764b9d8b9e question_number=14
  - master_bank_id=MB002596 paper_id=692ebeca613450764b9d8b9e question_number=21
  - master_bank_id=MB002598 paper_id=692ebeca613450764b9d8b9e question_number=23
  - master_bank_id=MB002733 paper_id=692ec50fe273d74a966a9ba4 question_number=8
  - master_bank_id=MB002912 paper_id=692ec67053dfe02e722ea4db question_number=37
  - master_bank_id=MB002918 paper_id=692ec67053dfe02e722ea4db question_number=43
  - master_bank_id=MB002919 paper_id=692ec67053dfe02e722ea4db question_number=44
  - master_bank_id=MB003131 paper_id=692ec98cfbf5b951d5263c48 question_number=31
  - master_bank_id=MB000627 paper_id=68ce4e7aaafa2b55b27a2554 question_number=2
  - master_bank_id=MB000638 paper_id=68ce4e7aaafa2b55b27a2554 question_number=13
  - master_bank_id=MB000779 paper_id=68ce5099d104af297985cace question_number=4
  - master_bank_id=MB000785 paper_id=68ce5099d104af297985cace question_number=10
  - master_bank_id=MB000794 paper_id=68ce5099d104af297985cace question_number=19
  - master_bank_id=MB000795 paper_id=68ce5099d104af297985cace question_number=20
  - master_bank_id=MB000926 paper_id=68ce53ddaafa2b55b27a4516 question_number=1
  - master_bank_id=MB000939 paper_id=68ce53ddaafa2b55b27a4516 question_number=14
  - master_bank_id=MB001059 paper_id=68ce5959d104af297985f09a question_number=9
  - master_bank_id=MB001067 paper_id=68ce5959d104af297985f09a question_number=17
  - master_bank_id=MB001074 paper_id=68ce5959d104af297985f09a question_number=24
  - master_bank_id=MB002305 paper_id=68d1232b59b7f00d1a8acfa3 question_number=5
  - master_bank_id=MB002315 paper_id=68d1232b59b7f00d1a8acfa3 question_number=15
  - master_bank_id=MB001756 paper_id=68ce78bfd104af297986788d question_number=6
  - master_bank_id=MB001757 paper_id=68ce78bfd104af297986788d question_number=7
  - master_bank_id=MB001758 paper_id=68ce78bfd104af297986788d question_number=8
  - master_bank_id=MB001760 paper_id=68ce78bfd104af297986788d question_number=10
  - master_bank_id=MB001772 paper_id=68ce78bfd104af297986788d question_number=22
  - master_bank_id=MB001886 paper_id=68ce7a1bd104af2979867ec7 question_number=11
  - master_bank_id=MB001898 paper_id=68ce7a1bd104af2979867ec7 question_number=23
  - master_bank_id=MB001953 paper_id=68ce7b1cd104af29798684ff question_number=3
  - master_bank_id=MB001957 paper_id=68ce7b1cd104af29798684ff question_number=7
  - master_bank_id=MB001975 paper_id=68ce7b1cd104af29798684ff question_number=25
  - master_bank_id=MB000069 paper_id=68ce2e7459b7f00d1a7c1b82 question_number=19
  - master_bank_id=MB002087 paper_id=68ce7edbd104af2979869487 question_number=12
  - master_bank_id=MB002088 paper_id=68ce7edbd104af2979869487 question_number=13
  - master_bank_id=MB002101 paper_id=68ce809859b7f00d1a7dd7bc question_number=1
  - master_bank_id=MB002125 paper_id=68ce809859b7f00d1a7dd7bc question_number=25
  - master_bank_id=MB000092 paper_id=68ce3286d104af29798549e6 question_number=17
  - master_bank_id=MB000105 paper_id=68ce3e9dd104af2979858854 question_number=5
  - master_bank_id=MB000111 paper_id=68ce3e9dd104af2979858854 question_number=11
  - master_bank_id=MB000204 paper_id=68ce436a59b7f00d1a7c9108 question_number=4
- Referenced images missing on disk: 0
